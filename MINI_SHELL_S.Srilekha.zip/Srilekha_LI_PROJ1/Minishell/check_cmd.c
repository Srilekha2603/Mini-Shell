/*
NAME                    : S.Srilekha
DATE                    : 06-04-2026
DESCRIPTION             : Implement a minimalistic shell, mini-shell(msh) as part of the Linux Internal module.*/
#include "minishell.h"
extern char *external_commands[250]; 
int check_command_type(char *command)
{
    char *builtins[] = {"cd","pwd","exit","echo","clear",NULL};     //Creating 2d array for internal commads
    for (int i = 0; builtins[i] != NULL; i++)       //To check the command is internal cmd
    {
        if(strcmp(command,builtins[i]) == 0)
            return BUILTIN; 
    }
    for(int i = 0;external_commands[i] != NULL; i++)       //To check the command is External cmd
    {       
        if(strncmp(command,external_commands[i],strlen(command)) == 0)
            return EXTERNAL;
    }
    return NO_COMMAND;      //If it is not External or builtin
}