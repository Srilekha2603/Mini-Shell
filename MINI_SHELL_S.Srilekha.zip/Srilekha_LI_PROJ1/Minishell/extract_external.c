/*
NAME                    : S.Srilekha
DATE                    : 06-04-2026
DESCRIPTION             : Implement a minimalistic shell, mini-shell(msh) as part of the Linux Internal module.*/
#include "minishell.h"
int npipe(char **argv)
{
    int i = 0,count = 0;
    int cmd_pos[10] = {0};
    //Find command starting positions and replace '|' with NULL
    cmd_pos[count] = 0;
    count++;
    for(i = 0; argv[i] != NULL; i++)
    {
        if(strcmp(argv[i], "|") == 0)
        {
            argv[i] = NULL;         
            cmd_pos[count] = i + 1;     //next command starts after |
            count++;
        }
    }
    for(i = 0; i < count; i++)
    {
        int pipefd[2];
        //creating pipe if there is next command
        if(i < count - 1){
            if(pipe(pipefd)==-1){
                perror("pipe");
                return -1;
            }
        }
        pid_t c1=fork();                     //create child1          
        if(c1>0){                            //parent process
            if(i < count - 1){
                close(pipefd[1]);
                dup2(pipefd[0],0);
                close(pipefd[0]);
            }
        }
        if(c1 == 0){   
            if(i < count - 1){                       //child process
            close(pipefd[0]);
            dup2(pipefd[1],1);
            close(pipefd[1]);
            }
            execvp(argv[cmd_pos[i]], argv + cmd_pos[i]);
            perror("execvp");
            exit(1);
        }   
    }
    for(i = 0; i < count; i++)
        wait(NULL);
    return 0;
}
void execute_external_commands(char *input_string)
{
    char *argv[30] = {0};
    int i = 0,flag=0;
    //converting input_string to 2d array
    char *token = strtok(input_string," ");
    while(token != NULL){
        //Allocate the memory
        argv[i] = malloc(strlen(token)+1);
        strcpy(argv[i],token);      //copy token
        i++;
        token=strtok(NULL," ");
    }
    argv[i]=NULL;
    for(int j = 0; argv[j] != NULL; j++){
        if(strcmp(argv[j],"|") == 0){       //CHeck pipes
            flag = 1;
            break;
        }
    }
    if(flag==1)
        npipe(argv);            //Execute pipe
    else{
        //Execute command
        if(execvp(argv[0],argv) == -1)
        {
            perror("execvp");
            exit(1);
        }
    }
}