/*
NAME                    : S.Srilekha
DATE                    : 06-04-2026
DESCRIPTION             : Implement a minimalistic shell, mini-shell(msh) as part of the Linux Internal module.*/
#include "minishell.h"
void extract_external_commands(char **external_commands)
{
    int fd = open("external_cmd.txt", O_RDONLY);                        //file containing commands
    if(fd == -1){
        perror("open");
        return;
    }
    char ch,buf[50];
    int i = 0, cmd_index = 0;
    while(read(fd, &ch, 1) > 0)
    {
        if (ch != '\n'){
            buf[i] = ch;                                             //store character
            i++;
        }
        else{
            buf[i] = '\0';                                             //terminate string
            external_commands[cmd_index] = malloc(strlen(buf) + 1);    //allocate memory for command
            strcpy(external_commands[cmd_index], buf);                 //copy command into array
            cmd_index++;
            i = 0;                                                     //reset buffer index
        }
    }
    //for last command in text file
    if(i > 0){
        buf[i] = '\0';
        external_commands[cmd_index] = malloc(strlen(buf) + 1);
        strcpy(external_commands[cmd_index], buf);
        cmd_index++;
    }
    external_commands[cmd_index] = NULL;                               //mark end
    //for(int i =0;external_commands[i]!=NULL;i++)
        //printf("%s\n",external_commands[i]);
    close(fd);
}